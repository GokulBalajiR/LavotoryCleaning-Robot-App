package com.example.tcr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class MainScreen extends AppCompatActivity {
    FirebaseAuth mAuth;

    ImageButton addDeviceButton,smallAddBtn,device1Btn,device2Btn,device3Btn,device4Btn,device5Btn,lgOut;
    TextView addDeviceATextView,tempTitle,gasTitle,humidityTitle;
    TextView greetingsTextView,humidityVal,tempVal,gasVal;
    String fullName;
    String fullEmail;
    String device_1_SN;
    String device_2_SN;
    String device_3_SN;
    String device_4_SN;
    String device_5_SN;


    FirebaseUser user;
    DatabaseReference reference,device1DataRef,device2DataRef,device3DataRef,device4DataRef,device5DataRef;
    String userId;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        //////////////////variable initialization///////////////////////////////


        mAuth =FirebaseAuth.getInstance();
        addDeviceATextView=(TextView)findViewById(R.id.addDeviceTextId);
        addDeviceButton=findViewById(R.id.addButtonId);
        lgOut=findViewById(R.id.logOutBtnId);
        device1Btn=findViewById(R.id.device1BtnId);
        device2Btn=findViewById(R.id.device2BtnId);
        device3Btn=findViewById(R.id.device3BtnId);
        device4Btn=findViewById(R.id.device4BtnId);
        device5Btn=findViewById(R.id.device5BtnId);

        user =FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users");
        userId=user.getUid();
        greetingsTextView=(TextView) findViewById(R.id.greetingsId);
        tempTitle=(TextView)findViewById(R.id.tempTitleId);
        gasTitle=(TextView)findViewById(R.id.gasTitleId);
        humidityTitle=(TextView)findViewById(R.id.humidityTitleId);
        humidityVal=(TextView)findViewById(R.id.humidityValId);
        tempVal=(TextView)findViewById(R.id.temperaturValId);
        gasVal=(TextView)findViewById(R.id.gasValId);

        ///////////variable initialization complete////////////////////////////


        smallAddBtn=(ImageButton)findViewById(R.id.smallAddBtnId);

        lgOut.setOnClickListener(view ->{
            mAuth.signOut();
            startActivity(new Intent(MainScreen.this,SignUpPage.class));
        });


        ///small button invisibility

       smallAddBtn.setEnabled(false);
       smallAddBtn.setVisibility(View.GONE);
       //////////////////////////////////////////

        ///////////////title invisibility//////////////
        tempTitle.setVisibility(View.GONE);
        humidityTitle.setVisibility(View.GONE);
        gasTitle.setVisibility(View.GONE);
        ////////////////////////////

        //add button Invisibility
        addDeviceButton.setEnabled(false);
        addDeviceButton.setVisibility(View.GONE);
        addDeviceATextView.setVisibility(View.GONE);
        /////////////////////////////////////


        //device buttons invisibility
        device1Btn.setEnabled(false);
        device1Btn.setVisibility(View.GONE);

        device2Btn.setEnabled(false);
        device2Btn.setVisibility(View.GONE);

        device3Btn.setEnabled(false);
        device3Btn.setVisibility(View.GONE);

        device4Btn.setEnabled(false);
        device4Btn.setVisibility(View.GONE);

        device5Btn.setEnabled(false);
        device5Btn.setVisibility(View.GONE);


        ///////////////////////////////////
        addDeviceButton.setOnClickListener(View ->{
            Log.i("BIg add button:","pressed");
            Intent intent= new Intent(MainScreen.this,AddDevice.class);
            startActivity(intent);
        });

        //////onclick lisner small add btn


        smallAddBtn.setOnClickListener(View ->{
            Intent intent= new Intent(MainScreen.this,AddDevice.class);
            startActivity(intent);
        });

        ///////////////////////////////////








        /////////////////getting object data for the user
        reference.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                UserProfile userProfile=snapshot.getValue(UserProfile.class);

                if(userProfile != null)
                {
                    fullName=userProfile.userName;
                    fullEmail=userProfile.userEmail;
                    device_1_SN=userProfile.device_1;
                    device_2_SN=userProfile.device_2;
                    device_3_SN=userProfile.device_3;
                    device_4_SN=userProfile.device_4;
                    device_5_SN=userProfile.device_5;



                    ////////////////////////////////end of progress bar comes here/////////////////////////////////



                     // noDevicescheck

                    if(device_1_SN.contains("nil") && device_2_SN.contains("nil") && device_3_SN.contains("nil") && device_4_SN.contains("nil") && device_5_SN.contains("nil") )
                    {



                        addDeviceButton.setVisibility(View.VISIBLE);
                        addDeviceButton.setEnabled(true);
                        addDeviceATextView.setVisibility(View.VISIBLE);
                        greetingsTextView.setText("Hi, "+userProfile.userName+". There are no devices registered. Please add a new device.");
                    }

                    else
                    {
                        //small add btn visible
                        smallAddBtn.setVisibility((View.VISIBLE));
                        smallAddBtn.setEnabled(true);
                        //tempTitle.setVisibility(View.VISIBLE);
                        //humidityTitle.setVisibility(View.VISIBLE);
                        gasTitle.setVisibility(View.VISIBLE);
                    }

                    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    if(!device_1_SN.contains("nil"))
                    {
                        if(!device_1_SN.contains("nil"))
                        {
                            device1Btn.setVisibility(View.VISIBLE);
                            device1Btn.setEnabled(true);

                        }

                        if(!device_2_SN.contains("nil"))
                        {
                            device2Btn.setVisibility(View.VISIBLE);
                            device2Btn.setEnabled(true);

                        }
                        if(!device_3_SN.contains("nil"))
                        {
                            device3Btn.setVisibility(View.VISIBLE);
                            device3Btn.setEnabled(true);

                        }
                        if(!device_4_SN.contains("nil"))
                        {
                            device4Btn.setVisibility(View.VISIBLE);
                            device4Btn.setEnabled(true);

                        }
                        if(!device_5_SN.contains("nil"))
                        {
                            device5Btn.setVisibility(View.VISIBLE);
                            device5Btn.setEnabled(true);

                        }








                        ///////////////////////which device to open in main screen/////////////////

                        if(device_2_SN.contains("nil") && device_3_SN.contains("nil") && device_4_SN.contains("nil") && device_5_SN.contains("nil"))
                        {
                            device1Btn.callOnClick();
                        }

                        else if(device_3_SN.contains("nil") && device_4_SN.contains("nil") && device_5_SN.contains("nil"))
                        {
                            device2Btn.callOnClick();
                        }

                        else if(device_4_SN.contains("nil") && device_5_SN.contains("nil"))
                        {
                            device3Btn.callOnClick();
                        }

                        else if(device_5_SN.contains("nil"))
                        {
                            device4Btn.callOnClick();
                        }

                        else if(!device_5_SN.contains("nil"))
                        {
                            device5Btn.callOnClick();
                        }
                        ////////////////////end : which device to open in main screen :end//////////////////////////////

                    }








                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Toast.makeText(MainScreen.this, "Something went Wrong !!", Toast.LENGTH_LONG).show();

            }
        });












        ////////////////////device onclick listener

        device1Btn.setOnClickListener(View ->{
            ////colour filter///
            device1Btn.setColorFilter(Color.parseColor("#16D2E6"));
            device2Btn.clearColorFilter();
            device3Btn.clearColorFilter();
            device4Btn.clearColorFilter();
            device5Btn.clearColorFilter();


            ///////////////////

            device1DataRef=FirebaseDatabase.getInstance().getReference("Devices").child(device_1_SN).child("Data");

            /*device1DataRef.child("temperature").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device1_TempValString= Objects.requireNonNull(snapshot.getValue()).toString();
                    tempVal.setText(device1_TempValString);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");


                }
            });*/



            /*device1DataRef.child("humidity").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device1_HumidityValString = Objects.requireNonNull(snapshot.getValue()).toString();
                    humidityVal.setText(device1_HumidityValString);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");

                }
            });*/


            /////////////////////////////////////////////gas
            device1DataRef.child("gas").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device1_GasValString = Objects.requireNonNull(snapshot.getValue()).toString();
                    gasVal.setText(device1_GasValString+" %");
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");

                }
            });



            //////////////////////////////////////gas



        });

        device2Btn.setOnClickListener(View ->{




            ////colour filter///
            device2Btn.setColorFilter(Color.parseColor("#16D2E6"));
            device1Btn.clearColorFilter();
            device3Btn.clearColorFilter();
            device4Btn.clearColorFilter();
            device5Btn.clearColorFilter();


            ///////////////////

            device2DataRef=FirebaseDatabase.getInstance().getReference("Devices").child(device_2_SN).child("Data");

           /* device2DataRef.child("temperature").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device2_TempValString= Objects.requireNonNull(snapshot.getValue()).toString();
                    tempVal.setText(device2_TempValString);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");


                }
            });
*/


           /* device2DataRef.child("humidity").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device2_HumidityValString = Objects.requireNonNull(snapshot.getValue()).toString();
                    humidityVal.setText(device2_HumidityValString);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");

                }
            });*/

            device2DataRef.child("gas").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device1_GasValString = Objects.requireNonNull(snapshot.getValue()).toString();
                    gasVal.setText(device1_GasValString+" %");
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");

                }
            });

        });


        device3Btn.setOnClickListener(View ->{


            ////colour filter///
            device3Btn.setColorFilter(Color.parseColor("#16D2E6"));
            device1Btn.clearColorFilter();
            device2Btn.clearColorFilter();
            device4Btn.clearColorFilter();
            device5Btn.clearColorFilter();


            ///////////////////

            device3DataRef=FirebaseDatabase.getInstance().getReference("Devices").child(device_3_SN).child("Data");

            /*device3DataRef.child("temperature").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device3_TempValString= Objects.requireNonNull(snapshot.getValue()).toString();
                    tempVal.setText(device3_TempValString);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");


                }
            });*/



            /*device3DataRef.child("humidity").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device3_HumidityValString = Objects.requireNonNull(snapshot.getValue()).toString();
                    humidityVal.setText(device3_HumidityValString);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");

                }
            });*/

            device3DataRef.child("gas").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device1_GasValString = Objects.requireNonNull(snapshot.getValue()).toString();
                    gasVal.setText(device1_GasValString+" %");
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");

                }
            });

        });

        device4Btn.setOnClickListener(View ->{



            ////colour filter///
            device4Btn.setColorFilter(Color.parseColor("#16D2E6"));
            device2Btn.clearColorFilter();
            device3Btn.clearColorFilter();
            device1Btn.clearColorFilter();
            device5Btn.clearColorFilter();


            ///////////////////

            device4DataRef=FirebaseDatabase.getInstance().getReference("Devices").child(device_4_SN).child("Data");

            /*device4DataRef.child("temperature").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device4_TempValString= Objects.requireNonNull(snapshot.getValue()).toString();
                    tempVal.setText(device4_TempValString);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");


                }
            });*/



            /*device4DataRef.child("humidity").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device4_HumidityValString = Objects.requireNonNull(snapshot.getValue()).toString();
                    humidityVal.setText(device4_HumidityValString);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");

                }
            });*/


            device4DataRef.child("gas").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device1_GasValString = Objects.requireNonNull(snapshot.getValue()).toString();
                    gasVal.setText(device1_GasValString+" %");
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");

                }
            });

        });

        device5Btn.setOnClickListener(View ->{


            ////colour filter///
            device5Btn.setColorFilter(Color.parseColor("#16D2E6"));
            device2Btn.clearColorFilter();
            device3Btn.clearColorFilter();
            device4Btn.clearColorFilter();
            device1Btn.clearColorFilter();


            ///////////////////

            device5DataRef=FirebaseDatabase.getInstance().getReference("Devices").child(device_5_SN).child("Data");

            /*device5DataRef.child("temperature").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device5_TempValString= Objects.requireNonNull(snapshot.getValue()).toString();
                    tempVal.setText(device5_TempValString);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");


                }
            });



            device5DataRef.child("humidity").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device5_HumidityValString = Objects.requireNonNull(snapshot.getValue()).toString();
                    humidityVal.setText(device5_HumidityValString);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");

                }
            });
*/

            device5DataRef.child("gas").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String device1_GasValString = Objects.requireNonNull(snapshot.getValue()).toString();
                    gasVal.setText(device1_GasValString+" %");
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i("blah","failed to read msg");

                }
            });

        });


        ///////////////////////////////////////////



    }
}