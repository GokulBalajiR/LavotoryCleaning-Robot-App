package com.example.tcr;

public class GlobalVariables {

    public  static boolean logged_in;
}



