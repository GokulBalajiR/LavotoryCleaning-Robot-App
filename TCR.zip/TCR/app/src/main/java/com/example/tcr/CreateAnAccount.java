package com.example.tcr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

public class CreateAnAccount extends AppCompatActivity {


    EditText fullName,passwordEdText,confirmPassword,emailEdText;
    FirebaseAuth mAuth;
    TextView error;
    String   fullNameStr,passwordStr,confirmPasswordStr,emailStr;
    ImageButton createAc,backButton;

    //errors
    String plzFillAll="Please fill all Constrains";
    String passwordLengthError ="The password should have atleast 8 charachters";
    String passConfirmNotEqual ="Password doesn't match Confirm Password";
    String passSpace ="The password cannot contain spaces";
    String invalidEmail ="Invalid Email";


    public void openSignUpPage(View view)
    {
        Intent intent= new Intent(CreateAnAccount.this,SignUpPage.class);
        startActivity(intent);

    }

    public void openLogin()
    {
        Intent intent= new Intent(CreateAnAccount.this,Login.class);
        startActivity(intent);
    }


    public static boolean containsWhiteSpace(final String testCode){
        if(testCode != null){
            for(int i = 0; i < testCode.length(); i++){
                if(Character.isWhitespace(testCode.charAt(i))){
                    return true;
                }
            }
        }
        return false;
    }



    public void createUser()
    {
        String email =emailEdText.getText().toString();
        String password =passwordEdText.getText().toString();
        String fullNameStrTemp = fullName.getText().toString();

        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {

                    //creating User Object

                    UserProfile  userObj =new UserProfile(fullNameStrTemp,email,"nil","nil","nil","nil","nil");

                    //Adding obj to realtime database

                    FirebaseDatabase.getInstance().getReference("Users")
                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .setValue(userObj).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                error.setText("User has been added to realtime database");
                                Log.i("database status","User has been added to realtime database");
                            }

                            else
                            {
                                Log.i("database status",task.getException().getMessage());
                            }
                        }
                    });
                    //user verification


                    FirebaseUser user =FirebaseAuth.getInstance().getCurrentUser();

                    if(user.isEmailVerified())
                    {
                        Toast.makeText(CreateAnAccount.this, "User registered successfully", Toast.LENGTH_LONG).show();
                        //user redirected to login activity
                        startActivity(new Intent(CreateAnAccount.this,Login.class));

                    }

                    else
                    {
                        user.sendEmailVerification();
                        Toast.makeText(CreateAnAccount.this, "Check your email for verification", Toast.LENGTH_SHORT).show();

                        error.setText("registered but, check email for verification");
                        //redirecting to login after verification page

                        openLogin();

                    }


                }
                else
                {
                    Toast.makeText(CreateAnAccount.this, "Registration Error:" +task.getException().getMessage(), Toast.LENGTH_LONG).show();

                }

            }
        });


    }



    public void createAccount()
    {

        error.setText("");
        if(fullName.getText().toString().isEmpty() ||passwordEdText.getText().toString().isEmpty() || confirmPassword.getText().toString().isEmpty() || emailEdText.getText().toString().isEmpty())
        {
            error.setText(plzFillAll);
        }

        else if(!Patterns.EMAIL_ADDRESS.matcher(emailEdText.getText().toString()).matches())
        {
            error.setText(invalidEmail);
        }

        else if(passwordEdText.getText().toString().length()<8)
        {
            error.setText(passwordLengthError);
        }

        else if(containsWhiteSpace(passwordEdText.getText().toString()))
        {
            error.setText(passSpace);
        }

        else if(!passwordEdText.getText().toString().equals(confirmPassword.getText().toString()))
        {
            error.setText(passConfirmNotEqual);
        }


        else
            {

                error.setText("all constrains are correct");


                fullNameStr =fullName.getText().toString();
                passwordStr=passwordEdText.getText().toString();
                confirmPasswordStr=confirmPassword.getText().toString();
                emailStr=emailEdText.getText().toString();

                createUser();






        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_an_account);

        error=(TextView) findViewById(R.id.errorTextViewLoginId);
        createAc=findViewById(R.id.createAccButton);

        fullName=(EditText) findViewById(R.id.fullNameEditText);
        passwordEdText=(EditText) findViewById(R.id.passwordEdittext);
        confirmPassword=(EditText) findViewById(R.id.confirmPasswordEditText);
        emailEdText=(EditText) findViewById(R.id.devicePasswordEditTextId);
        backButton=findViewById(R.id.backBtnId);


        mAuth =FirebaseAuth.getInstance();

        createAc.setOnClickListener(view ->{
            createAccount();
        });










    }
}