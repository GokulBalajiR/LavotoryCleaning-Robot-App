package com.example.tcr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class Login extends AppCompatActivity {


    EditText email,password;
    TextView errorMsg;
    FirebaseAuth mAuth;
    ImageButton loginBtn;
    Button newUserBtn;

    private  void loginUser()
    {
        String emailStr =email.getText().toString();
        String passwordStr =password.getText().toString();
        mAuth.signInWithEmailAndPassword(emailStr,passwordStr).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    if(mAuth.getCurrentUser().isEmailVerified() )
                    {
                        startActivity(new Intent(Login.this,MainScreen.class));

                    }

                    else
                    {
                        FirebaseUser user =FirebaseAuth.getInstance().getCurrentUser();
                        user.sendEmailVerification();

                        Toast.makeText(Login.this, "Please click the verification link sent to your Email id", Toast.LENGTH_LONG).show();

                    }

                }

                else
                {

                    Toast.makeText(Login.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        });



    }


    private void openCreateAnAcc()
    {
        startActivity(new Intent(Login.this,CreateAnAccount.class));
    }







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        password=(EditText) findViewById(R.id.devicePasswordEditTextId);
        email=(EditText) findViewById(R.id.deviceSNTextId);
        loginBtn=findViewById(R.id.loginImageButton);
        newUserBtn=findViewById(R.id.createNewAccButton);


        errorMsg=(TextView)findViewById(R.id.errorTextViewLoginId);
        mAuth=FirebaseAuth.getInstance();

        loginBtn.setOnClickListener(view ->{
            loginUser();
        });

        newUserBtn.setOnClickListener(view ->{
            openCreateAnAcc();
        });












    }
}