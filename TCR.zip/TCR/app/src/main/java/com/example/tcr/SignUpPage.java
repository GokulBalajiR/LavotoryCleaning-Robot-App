package com.example.tcr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class SignUpPage extends AppCompatActivity {

    public void openLoginPage(View view)
    {
        Intent intent= new Intent(this,Login.class);
        startActivity(intent);
    }

    public void openCreateAnAccount(View view)
    {
        Intent intent= new Intent(this,CreateAnAccount.class);
        startActivity(intent);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page);


    }
}