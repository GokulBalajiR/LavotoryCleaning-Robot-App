package com.example.tcr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AddDevice extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference deviceSNRef,reference,databaseReference,device1Ref,device2Ref,device3Ref,device4Ref,device5Ref,deviceEmailRef;
    FirebaseAuth myAuth;
    FirebaseUser user;
    String userName,fullEmail,device1_val,device2_val,device3_val,device4_val,device5_val;
    String userId,numberOfEmailsStr;
    int numberOfEmails;
    String userEmailStr;




    ImageButton backBtn,regDeviceBtn;
    TextView err;

    EditText SNnum, SNpass;


    public void passwordCheck()
    {
        databaseReference=FirebaseDatabase.getInstance().getReference("Devices");
        databaseReference.child(SNnum.getText().toString()).child("Password").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String passFromDatabase =snapshot.getValue(String.class);
                Log.i("blah","password read from database");

                if(SNpass.getText().toString().equals(passFromDatabase))
                {
                    //register device

                    ///register in users .uid.device1
                    FirebaseUser user =FirebaseAuth.getInstance().getCurrentUser();


                    if (user != null) {
                        device1Ref=FirebaseDatabase.getInstance().getReference("Users").child(user.getUid()).child("device_1");
                        device2Ref=FirebaseDatabase.getInstance().getReference("Users").child(user.getUid()).child("device_2");
                        device3Ref=FirebaseDatabase.getInstance().getReference("Users").child(user.getUid()).child("device_3");
                        device4Ref=FirebaseDatabase.getInstance().getReference("Users").child(user.getUid()).child("device_4");
                        device5Ref=FirebaseDatabase.getInstance().getReference("Users").child(user.getUid()).child("device_5");



                        //////obtaining object data/////////////////////
                        reference = FirebaseDatabase.getInstance().getReference("Users");
                        userId=user.getUid();
                        userEmailStr=user.getEmail();


                        reference.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                UserProfile userProfile=snapshot.getValue(UserProfile.class);


                                if(userProfile != null)
                                {
                                    userName=userProfile.userName;
                                    fullEmail=userProfile.userEmail;
                                    device1_val=userProfile.device_1;
                                    device2_val=userProfile.device_2;
                                    device3_val=userProfile.device_3;
                                    device4_val=userProfile.device_4;
                                    device5_val=userProfile.device_5;


                                    ////check where to put the new device

                                    if(device1_val.equals("nil") && device2_val.equals("nil") &&device3_val.equals("nil") &&device4_val.equals("nil") &&device5_val.equals("nil") )
                                    {
                                        device1Ref.setValue(SNnum.getText().toString());

                                        ////in device users list add the email////

                                        deviceEmailRef=FirebaseDatabase.getInstance().getReference("Devices").child(SNnum.getText().toString()).child("User_emails");

                                        deviceEmailRef.child("numberOfEmails").addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                numberOfEmailsStr=snapshot.getValue().toString();
                                                Log.i("blah","num of emails is "+numberOfEmailsStr);
                                                numberOfEmails=Integer.parseInt(numberOfEmailsStr);
                                                int newVal=numberOfEmails+1;
                                                String newValStr=String.valueOf(newVal);

                                                deviceEmailRef.child("numberOfEmails").setValue(newVal);

                                                deviceEmailRef.child("Email_"+newValStr).setValue(userEmailStr);

                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {
                                                Log.i("blah","something went wrong");

                                            }
                                        });


                                        ///////////end :in device users list add the email :end/////////////////////







                                        Toast.makeText(AddDevice.this, "Device 1 registered", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(AddDevice.this,MainScreen.class));


                                    }

                                    else if(!device1_val.equals("nil") && device2_val.equals("nil") &&device3_val.equals("nil") &&device4_val.equals("nil") &&device5_val.equals("nil"))
                                    {
                                        device2Ref.setValue(SNnum.getText().toString());


                                        ////in device users list add the email////

                                        deviceEmailRef=FirebaseDatabase.getInstance().getReference("Devices").child(SNnum.getText().toString()).child("User_emails");

                                        deviceEmailRef.child("numberOfEmails").addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                numberOfEmailsStr=snapshot.getValue().toString();
                                                Log.i("blah","num of emails is "+numberOfEmailsStr);
                                                numberOfEmails=Integer.parseInt(numberOfEmailsStr);
                                                int newVal=numberOfEmails+1;
                                                String newValStr=String.valueOf(newVal);

                                                deviceEmailRef.child("numberOfEmails").setValue(newVal);

                                                deviceEmailRef.child("Email_"+newValStr).setValue(userEmailStr);

                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {
                                                Log.i("blah","something went wrong");

                                            }
                                        });


                                        ///////////end :in device users list add the email :end/////////////////////
                                        Toast.makeText(AddDevice.this, "Device 2 registered", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(AddDevice.this,MainScreen.class));

                                    }

                                    else if(!device1_val.equals("nil") && !device2_val.equals("nil") &&device3_val.equals("nil") &&device4_val.equals("nil") &&device5_val.equals("nil"))
                                    {
                                        device3Ref.setValue(SNnum.getText().toString());

                                        ////in device users list add the email////

                                        deviceEmailRef=FirebaseDatabase.getInstance().getReference("Devices").child(SNnum.getText().toString()).child("User_emails");

                                        deviceEmailRef.child("numberOfEmails").addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                numberOfEmailsStr=snapshot.getValue().toString();
                                                Log.i("blah","num of emails is "+numberOfEmailsStr);
                                                numberOfEmails=Integer.parseInt(numberOfEmailsStr);
                                                int newVal=numberOfEmails+1;
                                                String newValStr=String.valueOf(newVal);

                                                deviceEmailRef.child("numberOfEmails").setValue(newVal);

                                                deviceEmailRef.child("Email_"+newValStr).setValue(userEmailStr);

                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {
                                                Log.i("blah","something went wrong");

                                            }
                                        });


                                        ///////////end :in device users list add the email :end/////////////////////



                                        Toast.makeText(AddDevice.this, "Device 3 registered", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(AddDevice.this,MainScreen.class));


                                    }

                                    else if(!device1_val.equals("nil") && !device2_val.equals("nil") && !device3_val.equals("nil") &&device4_val.equals("nil") &&device5_val.equals("nil"))
                                    {
                                        device4Ref.setValue(SNnum.getText().toString());

                                        ////in device users list add the email////

                                        deviceEmailRef=FirebaseDatabase.getInstance().getReference("Devices").child(SNnum.getText().toString()).child("User_emails");

                                        deviceEmailRef.child("numberOfEmails").addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                numberOfEmailsStr=snapshot.getValue().toString();
                                                Log.i("blah","num of emails is "+numberOfEmailsStr);
                                                numberOfEmails=Integer.parseInt(numberOfEmailsStr);
                                                int newVal=numberOfEmails+1;
                                                String newValStr=String.valueOf(newVal);

                                                deviceEmailRef.child("numberOfEmails").setValue(newVal);

                                                deviceEmailRef.child("Email_"+newValStr).setValue(userEmailStr);

                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {
                                                Log.i("blah","something went wrong");

                                            }
                                        });


                                        ///////////end :in device users list add the email :end/////////////////////

                                        Toast.makeText(AddDevice.this, "Device 4 registered", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(AddDevice.this,MainScreen.class));



                                    }

                                    else if(!device1_val.equals("nil") && !device2_val.equals("nil") && !device3_val.equals("nil") && !device4_val.equals("nil") &&device5_val.equals("nil"))
                                    {
                                        device5Ref.setValue(SNnum.getText().toString());

                                        ////in device users list add the email////

                                        deviceEmailRef=FirebaseDatabase.getInstance().getReference("Devices").child(SNnum.getText().toString()).child("User_emails");

                                        deviceEmailRef.child("numberOfEmails").addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                numberOfEmailsStr=snapshot.getValue().toString();
                                                Log.i("blah","num of emails is "+numberOfEmailsStr);
                                                numberOfEmails=Integer.parseInt(numberOfEmailsStr);
                                                int newVal=numberOfEmails+1;
                                                String newValStr=String.valueOf(newVal);

                                                deviceEmailRef.child("numberOfEmails").setValue(newVal);

                                                deviceEmailRef.child("Email_"+newValStr).setValue(userEmailStr);

                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {
                                                Log.i("blah","something went wrong");

                                            }
                                        });


                                        ///////////end :in device users list add the email :end/////////////////////

                                        Toast.makeText(AddDevice.this, "Device 5 registered", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(AddDevice.this,MainScreen.class));

                                    }

                                    else
                                    {
                                        err.setText("A user can have a maximum of only 5 devices");
                                        Intent intent= new Intent(AddDevice.this,MainScreen.class);
                                        startActivity(intent);
                                    }








                                }

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                Toast.makeText(AddDevice.this, "Something went Wrong !!", Toast.LENGTH_LONG).show();

                            }
                        });






                        ///////////////////end obj obtain////////////////

                        Log.i("blah","device registered");

                    }


                }
                else
                {
                    err.setText("invalid password");
                    //incorrect password
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.i("blah","failed to read pass value");

            }
        });




    }













    public void regAc(View view)
    {
        Log.i("blah","btn clicked");

        String devSN =SNnum.getText().toString();
        String devPass =SNpass.getText().toString();

        // SNum contains in devices and with the right password then add the email in that device and add the device in the email


        /////////////////////////serial number check/////////////////////////////////////////////////////
        deviceSNRef=FirebaseDatabase.getInstance().getReference().child("Devices").child(devSN);



        ValueEventListener eventListener=new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists())
                {
                    //add device
                    Log.i("blah","SN exists");

                    passwordCheck();
                }

                else if(!snapshot.exists())
                    {
                        Log.i("blah","SN doesn't exist");

                        err.setText("invalid Serial number");
                    }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.i("blah","something went wrong");

            }
        };
        deviceSNRef.addListenerForSingleValueEvent(eventListener);
        ///////////////////////////////////////////////////////////////////////////////////////







    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_device);

        backBtn=findViewById(R.id.backBtnId);
        regDeviceBtn=findViewById(R.id.regDeviceBtnId);
        SNnum=(EditText)findViewById(R.id.deviceSNTextId);
        SNpass=(EditText)findViewById(R.id.devicePasswordEditTextId);
        err =(TextView)findViewById(R.id.errTextid) ;


        backBtn.setOnClickListener(View ->{
            startActivity(new Intent(AddDevice.this,MainScreen.class));
        });




    }
}