package com.example.tcr;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Timer;
import java.util.TimerTask;
public class Intro extends AppCompatActivity {
    Timer timer;
    FirebaseAuth mAuth;
    FirebaseUser user;
    public void openSignupPage()
    {
        Intent intent= new Intent(this,SignUpPage.class);
        startActivity(intent);
    }
    public void openMainScreen()
    {
        Intent intent= new Intent(this,MainScreen.class);
        startActivity(intent);
    }
    public void pageChooser()
    {
        openMainScreen();
        if(user!= null && user.isEmailVerified()) {
            openMainScreen();
        }
        else if (user == null)
        {
            openSignupPage();
        }
        else if(!user.isEmailVerified())
        {
            Intent intent= new Intent(this,Login.class);
            startActivity(intent);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        mAuth=FirebaseAuth.getInstance();
        user=mAuth.getCurrentUser();
        timer =new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                pageChooser();

            }
        },2000);
    }
}
