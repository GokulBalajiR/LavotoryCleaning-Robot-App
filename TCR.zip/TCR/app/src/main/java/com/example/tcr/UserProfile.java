package com.example.tcr;

public class UserProfile {

    public String userName,userEmail,device_1,device_2,device_3,device_4,device_5;

    public UserProfile()
    {}


    public UserProfile(String inuserName,String inuserEmail,String indevice_1,String indevice_2,
                       String indevice_3,String indevice_4,String indevice_5)
    {

        userName=inuserName;
        userEmail=inuserEmail;
        device_1=indevice_1;
        device_2=indevice_2;
        device_3=indevice_3;
        device_4=indevice_4;
        device_5=indevice_5;

    }
}

